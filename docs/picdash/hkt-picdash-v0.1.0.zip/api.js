import { getConfig, normalizeBase, apiError } from "./config.js";

async function request(path, options = {}) {
  const config = await getConfig();
  if (!config.apiKey) throw new Error("请先在插件设置中填写 API Key");
  const headers = new Headers(options.headers || {});
  headers.set("X-Api-Key", config.apiKey);
  const response = await fetch(`${normalizeBase(config.apiBase)}${path}`, { ...options, headers });
  let body;
  try { body = await response.json(); } catch { throw new Error(`服务器返回了非 JSON 响应（HTTP ${response.status}）`); }
  if (!response.ok || body.code !== 0) throw new Error(apiError(body, `HTTP ${response.status}`));
  return body.data;
}

export async function listActivityAlbums() {
  return request("/activity-albums");
}

export async function listActivityMedia(albumId) {
  return request(`/activity-albums/${encodeURIComponent(albumId)}/media`);
}

export async function createActivityAlbum(albumName) {
  return request("/activity-albums", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ albumName, albumStatus: "1" })
  });
}

export async function ensureActivityAlbum(albumName) {
  const data = await listActivityAlbums();
  const albums = Array.isArray(data) ? data : (data?.rows || []);
  const existing = albums.find(album => String(album.albumName || album.name || "").trim() === albumName.trim());
  return existing || createActivityAlbum(albumName.trim());
}

export async function uploadFile(file, mode = "compress") {
  const form = new FormData();
  form.append("file", file, file.name || "image.jpg");
  form.append("mode", mode);
  form.append("quality", "0.85");
  form.append("maxWidth", "1920");
  form.append("maxHeight", "1920");
  return request("/files/upload", { method: "POST", body: form });
}

export async function addToActivityAlbum(albumId, mediaUrl, mediaName, cropParams = null) {
  const body = { mediaUrl, mediaType: "image" };
  if (mediaName?.trim()) body.mediaName = mediaName.trim();

  if (cropParams) {
    body.sourceUrl = cropParams.sourceUrl;
    body.cropX = cropParams.cropX;
    body.cropY = cropParams.cropY;
    body.cropWidth = cropParams.cropWidth;
    body.cropHeight = cropParams.cropHeight;
  }

  console.log("【PicDash】addToActivityAlbum body:", JSON.stringify(body));

  return request(`/activity-albums/${encodeURIComponent(albumId)}/media`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
}

export async function updateMediaName(albumId, mediaId, mediaName) {
  if (!albumId) throw new Error("缺少相册 ID");
  if (!mediaId) throw new Error("缺少媒体 ID");
  if (!mediaName?.trim()) throw new Error("媒体名称不能为空");
  return request(`/activity-albums/${encodeURIComponent(albumId)}/media/${encodeURIComponent(mediaId)}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ mediaName: mediaName.trim() })
  });
}

export async function deleteMedia(albumId, mediaId) {
  if (!albumId) throw new Error("缺少相册 ID");
  if (!mediaId) throw new Error("缺少媒体 ID");
  return request(`/activity-albums/${encodeURIComponent(albumId)}/media/${encodeURIComponent(mediaId)}`, {
    method: "DELETE"
  });
}

export async function uploadToActivityAlbum(file, albumId, mediaName, cropConfig = null) {
  if (!albumId) throw new Error("请先创建活动相册");

  if (cropConfig) {
    // 裁剪路径：上传原始图 → 带 crop 参数写入相册
    const uploaded = await uploadFile(file, "original");
    console.log("【PicDash】uploadFile(original) response:", JSON.stringify(uploaded));
    const mediaUrl = uploaded.url || uploaded.mediaUrl || uploaded.fileUrl || uploaded.sourceUrl || "";
    console.log("【PicDash】mediaUrl used:", mediaUrl);
    const media = await addToActivityAlbum(albumId, mediaUrl,
      mediaName || uploaded.originalFilename || file.name, {
        sourceUrl: mediaUrl,
        cropX: cropConfig.cropX,
        cropY: cropConfig.cropY,
        cropWidth: cropConfig.cropWidth,
        cropHeight: cropConfig.cropHeight
      });
    return { uploaded, media };
  }

  // 非裁剪路径（原行为）
  const uploaded = await uploadFile(file);
  console.log("【PicDash】uploadFile(compress) response:", JSON.stringify(uploaded));
  const mediaUrl = uploaded.url || uploaded.mediaUrl || uploaded.fileUrl || "";
  const media = await addToActivityAlbum(albumId, mediaUrl, mediaName || uploaded.originalFilename || file.name);
  return { uploaded, media };
}
