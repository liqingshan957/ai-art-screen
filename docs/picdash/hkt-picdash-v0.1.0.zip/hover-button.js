(() => {
  // ─── 悬浮上传按钮 ───
  let button;
  let target;
  let hideTimer;
  let showTimer;
  const hide = () => {
    clearTimeout(showTimer);
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => { button?.remove(); button = undefined; target = undefined; }, 180);
  };
  function show(image) {
    const rect = image.getBoundingClientRect();
    if (rect.width < 80 || rect.height < 80 || rect.bottom <= 0 || rect.top >= window.innerHeight || rect.right <= 0 || rect.left >= window.innerWidth) return;
    clearTimeout(hideTimer);
    clearTimeout(showTimer);
    target = image;
    showTimer = setTimeout(() => {
      if (!button) {
        button = document.createElement("button");
        button.type = "button";
        button.textContent = "上传";
        button.title = "PicDash 上传到活动相册";
        button.style.cssText = "position:fixed;z-index:2147483647;padding:5px 9px;border:0;border-radius:6px;background:#1a73e8;color:#fff;font:12px system-ui;box-shadow:0 2px 8px #0004;cursor:pointer;";
        button.addEventListener("mouseenter", () => { clearTimeout(hideTimer); clearTimeout(showTimer); });
        button.addEventListener("mouseleave", hide);
        button.addEventListener("click", onUploadClick);
        document.documentElement.appendChild(button);
      }
      const current = target?.getBoundingClientRect();
      if (!current) return hide();
      button.style.left = `${Math.max(4, current.left + 4)}px`;
      button.style.top = `${Math.max(4, current.top + 8)}px`;
    }, 220);
  }
  function reposition() {
    if (!button || !target) return;
    // 滚动时取消隐藏计时，避免 mouseover 误触发 hide 导致闪烁
    clearTimeout(hideTimer);
    clearTimeout(showTimer);
    const rect = target.getBoundingClientRect();
    if (rect.width < 80 || rect.height < 80 || rect.bottom <= 0 || rect.top >= window.innerHeight || rect.right <= 0 || rect.left >= window.innerWidth) { hide(); return; }
    button.style.left = `${Math.max(4, rect.left + 4)}px`;
    button.style.top = `${Math.max(4, rect.top + 8)}px`;
  }
  document.addEventListener("mouseover", event => { const image = event.target.closest?.("img"); if (image) show(image); else if (!event.target.closest?.("button")) hide(); }, true);
  document.addEventListener("scroll", reposition, true);

  // ─── 注入右侧面板（iframe 加载 sidepanel.html） ───
  let panel = null;

  function onUploadClick(event) {
    event.preventDefault();
    event.stopPropagation();
    const srcUrl = target?.currentSrc || target?.src;
    if (!srcUrl) return;

    // ① 直接存 pending URL（让 iframe 中的 sidepanel 能读到）
    chrome.storage.session.set({ pendingImageUrl: srcUrl }).catch(() => {});
    // ② 通知 service worker（设 badge + 同步 side panel）
    if (chrome.runtime?.sendMessage) {
      chrome.runtime.sendMessage({ type: "prepare-image", srcUrl }).catch(() => {});
    }

    showPanel();
  }

  function showPanel() {
    if (!panel) panel = createPanel();
    panel.classList.add("pd-open");
    // 刷新 iframe，让侧面板重新加载并读取 pendingImageUrl
    const iframe = panel.querySelector("iframe");
    if (iframe) iframe.src = chrome.runtime.getURL("sidepanel.html");
  }

  function createPanel() {
    const container = document.createElement("div");
    container.className = "pd-panel";

    // iframe 加载真实的侧面板
    const iframe = document.createElement("iframe");
    iframe.src = chrome.runtime.getURL("sidepanel.html?embedded=1");
    iframe.style.cssText = "width:100%;height:100%;border:0;display:block;";

    // 关闭按钮（覆盖在 iframe 右上角）
    const closeBtn = document.createElement("button");
    closeBtn.textContent = "✕";
    closeBtn.className = "pd-close";
    closeBtn.addEventListener("click", hidePanel);

    // 标题栏
    const header = document.createElement("div");
    header.className = "pd-header";
    header.innerHTML = `<img src="${chrome.runtime.getURL("icons/icon32.png")}" class="pd-logo"><strong>HKT PicDash</strong>`;
    header.appendChild(closeBtn);

    container.append(header, iframe);

    // 样式
    const style = document.createElement("style");
    style.textContent = `
      .pd-panel {
        all: initial;
        position: fixed;
        top: 0; right: 0;
        width: 380px; height: 100vh;
        z-index: 2147483646;
        background: #fff;
        box-shadow: -4px 0 24px rgba(0,0,0,.15);
        transform: translateX(100%);
        transition: transform .22s ease;
        display: flex;
        flex-direction: column;
      }
      .pd-panel.pd-open { transform: translateX(0); }
      .pd-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 16px;
        border-bottom: 1px solid #e8eaed;
        flex-shrink: 0;
        background: #fff;
      }
      .pd-header { gap: 8px; }
      .pd-logo { width: 18px; height: 18px; flex-shrink: 0; }
      .pd-header strong { font: 600 15px/1.5 system-ui, sans-serif; color: #202124; }
      .pd-close {
        all: initial;
        width: 28px; height: 28px;
        border-radius: 50%;
        background: #f1f3f4;
        border: 0;
        font: 16px/1 system-ui, sans-serif;
        color: #5f6368;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
      }
      .pd-close:hover { background: #e8eaed; }
      .pd-panel iframe { flex: 1; border: 0; display: block; }
    `;
    document.documentElement.append(style, container);
    return container;
  }

  function hidePanel() {
    if (!panel) return;
    panel.classList.remove("pd-open");
  }
})();
