import { listActivityAlbums, listActivityMedia, uploadToActivityAlbum, updateMediaName, deleteMedia } from "./api.js";
import { getConfig } from "./config.js";

const $ = id => document.getElementById(id);
// 嵌入模式（被 hover-button 的 iframe 加载）时隐藏标题栏
if (new URLSearchParams(location.search).get("embedded") === "1") {
  document.documentElement.classList.add("pd-embedded");
}
let lastUrl = "";
let previewUrl = "";
let mediaItems = [];          // 缓存的媒体数据，用于搜索过滤
let currentAlbumId = "";      // 当前选中的相册 ID
let pendingFile = null;       // 当前待上传的文件

const BLESSINGS = [
  '开心','如意','平安','健康','自在',
  '加油','微笑','快乐','美好','阳光',
  '温暖','幸运','幸福','甜蜜','灿烂',
  '从容','坦荡','明亮','温柔','坚定',
  '勇敢','赤诚','热烈','浪漫','纯粹',
  '做自己','放轻松','慢慢来','没关系','你真棒',
  '小确幸','好心情','有梦想','爱生活','在路上',
  '天天开心','万事胜意','百事无忧',
  '闪闪发光','人间值得','好好生活','天天向上',
  '保持热爱','奔赴山海','万物可爱','未来可期',
  '好事发生','如约而至','满心欢喜','来日方长',
  '不负春光','心中有光','素履以往','一往无前',
  '平安喜乐','前程似锦','梦想成真','如愿以偿',
  '得偿所愿','自由自在','无忧无虑','心之所向',
  '光芒万丈','乘风破浪','星辰大海','锦绣前程','未来已来',
  '开心每一天','生活明朗','好运常在','天天好心情',
  '笑口常开','日子滚烫','人间烟火','山河远阔',
  '眼里有光','心中有爱','脚下有路','未来有梦',
  '你要快乐','记得微笑','今天很好','明天更好',
  '生活很好','记得开心','顺顺利利','健健康康'
];

function pickRandomName() { return BLESSINGS[Math.floor(Math.random() * BLESSINGS.length)]; }

// ── 名称选择器 ──
let namePickerActive = false;
function showNamePicker() {
  if (namePickerActive) return;
  namePickerActive = true;
  const input = $("upload-name");
  // 移除旧的弹窗
  document.querySelectorAll(".name-picker-popup").forEach(el => el.remove());
  const popup = document.createElement("div");
  popup.className = "name-picker-popup";
  BLESSINGS.forEach(phrase => {
    const btn = document.createElement("button");
    btn.className = "name-picker-chip";
    btn.textContent = phrase;
    btn.addEventListener("click", () => { input.value = phrase; closeNamePicker(); });
    popup.appendChild(btn);
  });
  // 定位在输入框下方
  const rect = input.getBoundingClientRect();
  popup.style.cssText = `position:fixed;top:${rect.bottom + 4}px;left:${rect.left}px;width:${rect.width}px;`;
  document.body.appendChild(popup);
}
function closeNamePicker() {
  namePickerActive = false;
  document.querySelectorAll(".name-picker-popup").forEach(el => el.remove());
}

function setStatus(text, error = false) { $("status").textContent = text; $("status").className = `status ${error ? "error" : "muted"}`; }

function showPreview(file) {
  if (previewUrl) URL.revokeObjectURL(previewUrl);
  previewUrl = URL.createObjectURL(file);
  $("upload-preview").src = previewUrl;
}

// ── 上传区域状态管理 ──
let doneTimer = null;  // 上传完成后的自动重置计时器

function setUploadState(state, file) {
  // 清除上次的自动重置计时器
  if (doneTimer) { clearTimeout(doneTimer); doneTimer = null; }

  $("upload-area").className = `upload-area state-${state}`;
  if (file) { pendingFile = file; showPreview(file); }
  if (state === "empty") { pendingFile = null; previewUrl && URL.revokeObjectURL(previewUrl); previewUrl = ""; $("upload-preview").src = ""; $("upload-name").value = ""; $("copy-url").classList.remove("hidden"); $("upload-submit").classList.remove("hidden"); }
  if (state === "done") {
    $("copy-url").classList.remove("hidden"); $("upload-submit").classList.add("hidden"); $("upload-cancel").textContent = "关闭";
    // 2.5 秒后自动清空，方便连续上传
    doneTimer = setTimeout(() => setUploadState("empty"), 2500);
  }
  if (state === "pending") { $("copy-url").classList.add("hidden"); $("upload-submit").classList.remove("hidden"); $("upload-cancel").textContent = "取消"; }
  if (state === "uploading") { $("upload-status").textContent = "正在上传…"; $("upload-status").classList.remove("hidden"); }
  if (state !== "uploading") { $("upload-status").classList.add("hidden"); }
}

async function uploadPendingUrl() {
  const { pendingImageUrl } = await chrome.storage.session.get("pendingImageUrl");
  if (!pendingImageUrl) return;
  try {
    const response = await fetch(pendingImageUrl);
    if (!response.ok) throw new Error(`图片下载失败（HTTP ${response.status}）`);
    const blob = await response.blob();
    const file = new File([blob], `image-${Date.now()}.jpg`, { type: blob.type || "image/jpeg" });
    setUploadState("pending", file);
  } catch (error) { setStatus(error.message, true); }
}

async function loadAlbums() {
  try {
    const data = await listActivityAlbums();
    const albums = Array.isArray(data) ? data : (data?.rows || []);
    const config = await chrome.storage.sync.get({ activityAlbumId: "" });
    const ids = albums.map(album => String(album.id ?? album.albumId));
    const selected = ids.includes(String(config.activityAlbumId)) ? String(config.activityAlbumId) : ids[0] || "";
    $("album").replaceChildren(...albums.map(album => { const id = String(album.id ?? album.albumId); const option = new Option(album.albumName || album.name || `相册 ${id}`, id); option.selected = id === selected; return option; }));
    if (selected) await chrome.storage.sync.set({ activityAlbumId: selected });
    $("album-status").textContent = albums.length ? `共 ${albums.length} 个相册，默认选择第一个` : "暂无相册，请先到设置中创建";
    if (selected) await loadMedia(selected);
  } catch (error) { $("album-status").textContent = error.message; }
}

// ----- 搜索与渲染 -----
function renderMedia() {
  const query = ($("media-search").value || "").trim().toLowerCase();
  const filtered = query
    ? mediaItems.filter(item => (item.mediaName || item.mediaUrl || "").toLowerCase().includes(query))
    : mediaItems;
  $("media-count").textContent = query ? `${filtered.length}/${mediaItems.length}` : "";

  if (!filtered.length) {
    $("media-list").innerHTML = `<p class="muted">${mediaItems.length ? "无匹配结果" : "当前相册暂无图片"}</p>`;
    return;
  }

  $("media-list").replaceChildren(...filtered.map(item => createMediaCard(item)));
}

function createMediaCard(item) {
  const card = document.createElement("article");
  card.className = "media-card";
  card.dataset.mediaId = item.mediaId || item.id || "";
  card.dataset.mediaUrl = item.mediaUrl || item.url || "";

  const image = document.createElement("img");
  image.src = item.mediaUrl || item.url || "";
  image.alt = item.mediaName || "图片";

  const info = document.createElement("div");
  info.className = "media-info";

  const nameEl = document.createElement("strong");
  nameEl.className = "media-name";
  nameEl.textContent = item.mediaName || "未命名图片";
  nameEl.title = "点击重命名";

  const date = document.createElement("small");
  date.textContent = item.createTime || item.createdAt || "";

  info.append(nameEl, date);

  // 删除按钮
  const delBtn = document.createElement("button");
  delBtn.className = "media-delete";
  delBtn.innerHTML = "✕";
  delBtn.title = "删除图片";
  delBtn.addEventListener("click", async event => {
    event.stopPropagation();
    if (!confirm("确定删除这张图片？")) return;
    try {
      await deleteMedia(currentAlbumId, card.dataset.mediaId);
      setStatus("图片已删除");
      await loadMedia(currentAlbumId);
    } catch (error) {
      setStatus(`删除失败：${error.message}`, true);
    }
  });

  card.append(image, info, delBtn);

  // 重命名：点击名称进入编辑模式
  nameEl.addEventListener("click", () => startRename(card, item));

  return card;
}

// ----- 重命名 -----
let renameActive = null;

function startRename(card, item) {
  if (renameActive) cancelRename(renameActive);
  const nameEl = card.querySelector(".media-name");
  const currentName = item.mediaName || "";
  const input = document.createElement("input");
  input.type = "text";
  input.className = "media-rename-input";
  input.value = currentName;
  input.maxLength = 100;
  input.autofocus = true;
  nameEl.replaceWith(input);
  renameActive = { card, item, nameEl, input };
  input.addEventListener("keydown", event => {
    if (event.key === "Enter") saveRename();
    if (event.key === "Escape") cancelRename(renameActive);
  });
  input.addEventListener("blur", () => {
    setTimeout(() => { if (renameActive) saveRename(); }, 150);
  });
  input.select();
}

async function saveRename() {
  if (!renameActive) return;
  const { card, item, nameEl, input } = renameActive;
  const newName = input.value.trim();
  const mediaId = card.dataset.mediaId;
  if (!newName || newName === (item.mediaName || "")) { cancelRename(renameActive); return; }
  input.disabled = true;
  input.style.opacity = "0.5";
  if (!mediaId) { setStatus("重命名失败：缺少媒体 ID", true); cancelRename(renameActive); return; }
  try {
    await updateMediaName(currentAlbumId, mediaId, newName);
    item.mediaName = newName;
    cancelRename(renameActive);
    renderMedia();
  } catch (error) {
    input.disabled = false;
    input.style.opacity = "1";
    input.focus();
    setStatus(`重命名失败：${error.message}`, true);
  }
}

function cancelRename(active) {
  if (!active) return;
  const { nameEl, input } = active;
  if (input.parentNode) input.replaceWith(nameEl);
  renameActive = null;
}

async function loadMedia(albumId) {
  currentAlbumId = albumId;
  try {
    const data = await listActivityMedia(albumId);
    mediaItems = Array.isArray(data) ? data : (data?.rows || []);
    mediaItems.forEach(item => { if (!item.mediaName) item.mediaName = ""; });
    renderMedia();
  } catch (error) {
    mediaItems = [];
    $("media-list").innerHTML = `<p class="error">${error.message}</p>`;
  }
}

// ── 裁剪计算 ──
async function calcCropFromFile(file, cfg) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      const nw = img.naturalWidth, nh = img.naturalHeight;
      const l = parseFloat(cfg.cropLeftMargin) / 100;
      const r = parseFloat(cfg.cropRightMargin) / 100;
      const t = parseFloat(cfg.cropTopMargin) / 100;
      const b = parseFloat(cfg.cropBottomMargin) / 100;
      resolve({
        cropX: Math.min(Math.round(nw * l), nw - 1),
        cropY: Math.min(Math.round(nh * t), nh - 1),
        cropWidth: Math.max(1, Math.round(nw * (1 - l - r))),
        cropHeight: Math.max(1, Math.round(nh * (1 - t - b)))
      });
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("无法读取图片尺寸")); };
    img.src = url;
  });
}

// ── 上传流程 ──
async function upload(file) {
  if (!file.type.startsWith("image/")) return setStatus(`${file.name} 不是图片`, true);
  const albumId = $("album").value;
  if (!albumId) return setStatus("请先在设置中创建活动相册", true);
  showPreview(file);
  setUploadState("uploading");

  const cfg = await getConfig();
  let cropConfig = null;
  if (cfg.cropEnabled) {
    try { cropConfig = await calcCropFromFile(file, cfg); }
    catch (e) { console.warn("裁剪尺寸读取失败，使用普通上传模式", e); }
  }

  const name = $("upload-name").value.trim() || pickRandomName();
  const result = await uploadToActivityAlbum(file, albumId, name, cropConfig);
  lastUrl = result.uploaded.url;
  setStatus(`${file.name} 已上传`);
  setUploadState("done");
  await loadMedia(albumId);
}

function uploadFiles(files) {
  // 多张图片：直接全部上传（跳过 pending 状态）
  if (files.length > 1) {
    [...files].forEach(file => upload(file).catch(error => setStatus(error.message, true)));
    return;
  }
  // 单张：进入 pending 状态等用户确认
  setUploadState("pending", files[0]);
}

// ── 事件绑定（始终有效） ──
$("settings").addEventListener("click", () => chrome.runtime.openOptionsPage());
$("setup-btn").addEventListener("click", () => chrome.runtime.openOptionsPage());

// ── 配置检测：无 API Key 时显示引导卡片 ──
async function ensureConfigured() {
  const config = await getConfig();
  return config && !!config.apiKey;
}

function showSetupGuide() {
  const hiddenIds = ["album", "album-status", "upload-area", "media-section", "status"];
  hiddenIds.forEach(id => { const el = $(id); if (el) el.classList.add("hidden"); });
  $("setup-guide").classList.remove("hidden");
}

const configured = await ensureConfigured();

if (configured) {
  // ── 已配置 API Key：正常功能 ──
  const area = $("upload-area");
  area.addEventListener("dragover", event => { event.preventDefault(); area.classList.add("dragging"); });
  area.addEventListener("dragleave", () => area.classList.remove("dragging"));
  area.addEventListener("drop", async event => {
    event.preventDefault();
    area.classList.remove("dragging");
    const files = [...event.dataTransfer.files];
    if (files.length) return uploadFiles(files);
    const url = (event.dataTransfer.getData("text/uri-list") || event.dataTransfer.getData("text/plain")).split("\n")[0].trim();
    if (!/^https?:\/\//i.test(url)) return setStatus("没有读取到可下载的图片", true);
    try {
      const response = await fetch(url);
      if (!response.ok) throw new Error(`图片下载失败（HTTP ${response.status}）`);
      const blob = await response.blob();
      await upload(new File([blob], `image-${Date.now()}.jpg`, { type: blob.type || "image/jpeg" }));
    } catch (error) { setStatus(error.message, true); }
  });
  area.addEventListener("click", () => {
    if (area.classList.contains("state-empty") || area.classList.contains("state-done")) {
      $("file-input").click();
    }
  });
  // 鼠标进入 done 状态区域 → 取消自动重置，方便用户复制 URL
  area.addEventListener("mouseenter", () => { if (doneTimer) { clearTimeout(doneTimer); doneTimer = null; } });
  area.addEventListener("mouseleave", () => { if ($("upload-area").classList.contains("state-done")) { doneTimer = setTimeout(() => setUploadState("empty"), 2500); } });

  $("file-input").addEventListener("change", event => { if (event.target.files.length) uploadFiles(event.target.files); });
  $("album").addEventListener("change", event => chrome.storage.sync.set({ activityAlbumId: event.target.value }));
  $("upload-submit").addEventListener("click", () => { if (pendingFile) upload(pendingFile).catch(error => setStatus(error.message, true)); });
  $("upload-cancel").addEventListener("click", () => setUploadState("empty"));
  $("copy-url").addEventListener("click", event => { event.stopPropagation(); navigator.clipboard.writeText(lastUrl); });
  $("name-picker-btn").addEventListener("click", event => { event.stopPropagation(); showNamePicker(); });
  // 点击其他地方关闭名称选择器
  document.addEventListener("click", event => { if (namePickerActive && !event.target.closest(".name-picker-popup") && event.target.id !== "name-picker-btn") closeNamePicker(); });
  $("media-search").addEventListener("input", () => renderMedia());

  chrome.action.setBadgeText({ text: "" });

  const pending = await chrome.storage.session.get("pendingImageUrl");
  if (pending.pendingImageUrl) uploadPendingUrl();

  chrome.runtime.onMessage.addListener(async message => {
    if (message?.type === "pending-image") {
      chrome.action.setBadgeText({ text: "" });
      const current = await chrome.storage.session.get("pendingImageUrl");
      if (current.pendingImageUrl) uploadPendingUrl();
    }
  });
  chrome.storage.onChanged.addListener((changes, area) => { if (area === "sync" && changes.activityAlbumId) loadAlbums(); });
  loadAlbums();
} else {
  showSetupGuide();
}

// ── 监听 API Key 保存 ──
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "sync") return;
  if (changes.apiKey?.newValue) {
    window.location.reload();
  }
});
