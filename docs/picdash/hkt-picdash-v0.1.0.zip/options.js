import { DEFAULTS } from "./config.js";
import { createActivityAlbum } from "./api.js";

const $ = id => document.getElementById(id);
const config = await chrome.storage.sync.get(DEFAULTS);
$("apiKey").value = config.apiKey || "";
$("albumName").value = config.activityAlbumName || "";
$("albumStatus").textContent = config.activityAlbumId ? `当前相册：${config.activityAlbumName || "已创建相册"}` : "尚未设置活动相册";

// ── 裁剪设置 ──
$("cropEnabled").checked = config.cropEnabled;
$("cropTopMargin").value = config.cropTopMargin || "";
$("cropBottomMargin").value = config.cropBottomMargin || "";
$("cropLeftMargin").value = config.cropLeftMargin || "";
$("cropRightMargin").value = config.cropRightMargin || "";

function toggleCropFields() {
  $("cropFields").style.display = $("cropEnabled").checked ? "grid" : "none";
}
toggleCropFields();

function saveCropSettings() {
  chrome.storage.sync.set({
    cropEnabled: $("cropEnabled").checked,
    cropTopMargin: $("cropTopMargin").value || "0",
    cropBottomMargin: $("cropBottomMargin").value || "0",
    cropLeftMargin: $("cropLeftMargin").value || "0",
    cropRightMargin: $("cropRightMargin").value || "0"
  });
}

$("cropEnabled").addEventListener("change", () => {
  toggleCropFields();
  saveCropSettings();
});
["cropTopMargin", "cropBottomMargin", "cropLeftMargin", "cropRightMargin"]
  .forEach(id => $(id).addEventListener("input", saveCropSettings));

$("save").addEventListener("click", async () => {
  await chrome.storage.sync.set({ apiKey: $("apiKey").value.trim() });
  $("saved").textContent = "✅ 已保存，返回面板即可使用";
  setTimeout(() => { $("saved").textContent = ""; }, 2500);
});

$("createAlbum").addEventListener("click", async () => {
  const albumName = $("albumName").value.trim();
  if (!albumName) return $("albumStatus").textContent = "请填写相册名称";
  try {
    $("albumStatus").textContent = "正在创建…";
    const album = await createActivityAlbum(albumName);
    const albumId = typeof album === "number" || typeof album === "string" ? album : (album?.id ?? album?.albumId);
    if (!albumId) throw new Error("接口没有返回相册 ID");
    await chrome.storage.sync.set({ activityAlbumId: String(albumId), activityAlbumName: albumName });
    $("albumStatus").textContent = `当前相册：${albumName}`;
  } catch (error) { $("albumStatus").textContent = error.message; }
});
