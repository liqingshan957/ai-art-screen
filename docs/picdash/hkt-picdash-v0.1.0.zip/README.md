# HKT PicDash

Chrome MV3 extension for quickly uploading webpage or local images to an HKT activity album.

## Features

- Hover an image and click the upload button.
- Right-click an image to send it to the side panel.
- Drag or select local images in the side panel.
- Create an activity album from the extension settings.
- Select an album from the current tenant's album list.
- Preview images before upload and browse the current album's media.
- Copy the URL of the most recent upload.

## Local setup

1. Open `chrome://extensions`.
2. Enable Developer mode.
3. Choose **Load unpacked** and select this directory.
4. Open the extension options and enter an API Key.
5. Create an activity album in the options page.
6. Open the side panel, select an album, and upload an image.

The API base URL is built in:

```text
https://vapi.hkting.com/api/open-api/v1
```

The API Key needs both `image` and `activity` scopes.

## Security

The current version stores the API Key in Chrome Sync and is intended for internal testing. Do not commit API Keys or distribute this version publicly. For external distribution, put the HKT API Key behind a server-side proxy and store only a user session token in the extension.

See [PLUGIN_USAGE.md](PLUGIN_USAGE.md) for the complete workflow, API mapping, testing notes, and browser compatibility details.
