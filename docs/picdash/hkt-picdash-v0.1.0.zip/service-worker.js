chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.create({ id: "picdash-upload-image", title: "上传图片到 HKT 活动相册", contexts: ["image"] });
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

// 右键菜单 — 有用户手势，同步调 sidePanel.open() 保留手势
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "picdash-upload-image" || !info.srcUrl) return;
  // ① 先同步打开面板（不 await，保留用户手势）
  chrome.sidePanel.open({ tabId: tab.id });
  // ② 再异步存数据（面板加载时会从 session storage 读取）
  chrome.storage.session.set({ pendingImageUrl: info.srcUrl });
});

// 悬浮按钮消息 — 没有用户手势，无法打开面板，只存 URL + 设角标引导
chrome.runtime.onMessage.addListener((message, sender) => {
  if (message?.type !== "prepare-image" || !message.srcUrl) return;
  chrome.storage.session.set({ pendingImageUrl: message.srcUrl });
  chrome.runtime.sendMessage({ type: "pending-image" }).catch(() => {});
  chrome.action.setBadgeText({ text: "1", tabId: sender.tab?.id });
  chrome.action.setBadgeBackgroundColor({ color: "#1a73e8" });
});
