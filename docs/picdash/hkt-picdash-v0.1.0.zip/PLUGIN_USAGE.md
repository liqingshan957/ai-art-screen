# HKT PicDash 使用说明

## 当前功能

- 鼠标移动到网页普通图片上显示“上传”按钮。
- 点击悬停按钮后自动打开右侧插件面板。
- 网页图片右键上传。
- 侧边栏拖拽或选择本地图片上传。
- 设置页创建活动相册。
- 侧边栏下拉选择当前租户的活动相册，默认选择第一个。
- 上传前显示图片预览，上传后显示结果预览。
- 展示当前相册中的图片、名称和上传日期。
- 支持复制最近上传图片 URL。

## 使用流程

### 1. 加载插件

打开：

```text
chrome://extensions
```

开启“开发者模式”，选择“加载已解压的扩展程序”，目录为：

```text
E:\job\projects\hkt\projects\plugin-img
```

### 2. 设置 API Key 和创建相册

打开插件“扩展程序选项”：

1. 填写 API Key。
2. 填写活动相册名称。
3. 点击“创建活动相册”。

创建成功后，相册 ID 由插件内部保存，用户不需要填写活动 ID 或相册 ID。

### 3. 上传图片

打开插件侧边栏：

1. 从下拉框选择活动相册，默认选择第一个。
2. 图片名称/备注为选填项；为空时使用文件名。
3. 拖拽图片、选择本地图片，或使用网页图片悬停/右键入口。
4. 确认预览后上传。

设置页创建相册后，已打开的侧边栏会自动刷新相册列表。

## API 调用链

API Base：

```text
https://vapi.hkting.com/api/open-api/v1
```

需要 API Key 同时拥有 `image` 和 `activity` Scope。

### 查询活动相册

```http
GET /activity-albums
X-Api-Key: ak_xxx
```

插件不传 `activityId`，按当前租户读取活动相册列表。

### 创建活动相册

```http
POST /activity-albums
Content-Type: application/json
X-Api-Key: ak_xxx

{
  "albumName": "活动现场",
  "albumStatus": "1"
}
```

`activityId` 不传。插件兼容创建接口返回 `id`、`albumId` 或数字 ID。

### 上传文件

```http
POST /files/upload
Content-Type: multipart/form-data
X-Api-Key: ak_xxx
```

插件内置图片处理参数：

```text
mode=compress
quality=0.85
maxWidth=1920
maxHeight=1920
```

### 写入活动相册

```http
POST /activity-albums/{albumId}/media
X-Api-Key: ak_xxx
```

查询参数：

```text
mediaUrl=上传接口返回的图片 URL
mediaType=image
mediaName=图片名称或文件名，可选
```

## 悬停上传按钮兼容范围

当前支持：

- 普通网页 `<img>` 图片。
- `picture` 元素中的图片。
- iframe 内的普通图片。
- 图片加载完成后的懒加载图片。

当前限制：

- CSS `background-image` 暂不显示按钮。
- Canvas 绘制的图片暂不支持。
- 视频封面暂不支持。
- `chrome://`、Chrome Web Store、浏览器内置 PDF 页面不能注入按钮。
- 很小的图标和头像默认忽略。
- 防盗链或 `blob:` 图片可能显示按钮，但下载阶段可能失败。
- Shadow DOM 中的图片在个别网站可能无法识别。

悬停按钮有短暂延迟，避免鼠标快速经过图片时产生闪烁和误触。

## 测试检查

修改插件后重新加载：

```text
chrome://extensions → 重新加载
```

测试顺序建议：

1. 设置页保存 API Key。
2. 创建一个活动相册。
3. 打开侧边栏，确认下拉框出现相册。
4. 选择本地图片，确认上传前预览。
5. 确认上传后当前相册图片列表刷新。
6. 在网页图片上测试悬停按钮和右键菜单。

调试位置：

- `chrome://extensions` → 插件 → Service Worker → 检查。
- 侧边栏右键 → 检查。
- DevTools 的 Network 查看 API 请求和返回的 `code`、`message`。

## 发布注意事项

当前插件把 API Key 保存在 Chrome Sync 配置中，适合内部测试，不适合直接公开分发。

正式发布建议改为：

```text
插件 → 自己的后端代理 → HKT OpenAPI
```

将 HKT API Key 保存在后端，插件只保存用户登录 Token，避免 API Key 被提取和滥用。
