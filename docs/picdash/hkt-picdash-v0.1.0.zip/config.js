export const DEFAULTS = {
  apiBase: "https://vapi.hkting.com/api/open-api/v1",
  apiKey: "",
  activityAlbumId: "",
  activityAlbumName: "",
  mode: "compress",
  quality: "0.85",
  maxWidth: "1920",
  maxHeight: "1920",
  // ── 裁剪配置 ──
  cropEnabled: false,
  cropTopMargin: "5.26",
  cropBottomMargin: "21.05",
  cropLeftMargin: "7.84",
  cropRightMargin: "7.84"
};

const LEGACY_API_BASE = "https://cms.hkting.com/api/open-api/v1";

export async function getConfig() {
  const config = await chrome.storage.sync.get(DEFAULTS);
  if (config.apiBase === LEGACY_API_BASE) {
    config.apiBase = DEFAULTS.apiBase;
    await chrome.storage.sync.set({ apiBase: DEFAULTS.apiBase });
  }
  return config;
}

export function normalizeBase(value) {
  return String(value || DEFAULTS.apiBase).replace(/\/+$/, "");
}

export function apiError(response, fallback) {
  if (!response) return fallback;
  return response.message || `接口错误（${response.code ?? "未知"}）`;
}
